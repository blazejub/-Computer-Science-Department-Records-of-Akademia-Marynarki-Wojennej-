import Form from "./maincomponents/Form"
function Main() {
    return (
<main>
    <div className="Main">
         <Form/> 
    </div>
</main>
)}
export default Main;