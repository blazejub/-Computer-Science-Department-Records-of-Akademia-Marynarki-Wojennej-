function Footer() {
    return (
        <footer>
            <div className="napis">
                Akademia Marynarki Wojennej
                <br/>
                im. Bohaterów Westerplatte
                <br/>
                All Rights Reserved.
                <br/>
            </div>
        </footer>
    );
}

export default Footer;
